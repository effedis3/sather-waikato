/*
2000-8 K.Kodama
*/

#include <sys/time.h>
#include <unistd.h>
#include <time.h>

static struct timeval sa_tv0;

void sa_tv_mark_time(){
  struct timezone tz;
  int res;
  res=gettimeofday(&sa_tv0, &tz);
}

int sa_tv_difftime(){
  struct timeval tv1;
  struct timezone tz;
  int res;
  res=gettimeofday(&tv1, &tz);
  return ((tv1.tv_sec - sa_tv0.tv_sec)*1000+
		  (tv1.tv_usec - sa_tv0.tv_usec)/1000);
}

int sa_tv_sec(){
  struct timeval tv;
  struct timezone tz;
  int res;
  res=gettimeofday(&tv, &tz);
  return (tv.tv_sec);
}

void* sa_sec_usec(){
  int res;
  struct timeval tv;
  struct timezone tz;
  static char s[100];
  /* long t; t=time(0); return t; */
  res=gettimeofday(&tv, &tz);
  sprintf(&s,"%d %d",tv.tv_sec, tv.tv_usec);
  return s;
}

int sa_u_time(){
  long t; t=time(0); return t;
}


int sa_tm_sec(){
  long t;
  struct tm *tmbuf;
  t=time(0); tmbuf=localtime(&t); return tmbuf->tm_sec;
}

int sa_tm_min(){
        long t;
        struct tm *tmbuf;
        t=time(0); tmbuf=localtime(&t); return tmbuf->tm_min;
}

int sa_tm_hour(){
        long t;
        struct tm *tmbuf;
        t=time(0); tmbuf=localtime(&t); return tmbuf->tm_hour;
}

int sa_tm_mday(){
        long t;
        struct tm *tmbuf;
        t=time(0); tmbuf=localtime(&t); return tmbuf->tm_mday;
}

int sa_tm_mon(){
        long t;
        struct tm *tmbuf;
        t=time(0); tmbuf=localtime(&t); return(tmbuf->tm_mon);
}

int sa_tm_year(){
        long t;
        struct tm *tmbuf;
        t=time(0); tmbuf=localtime(&t); return(tmbuf->tm_year);
}

int sa_tm_wday(){
        long t;
        struct tm *tmbuf;
        t=time(0); tmbuf=localtime(&t); return tmbuf->tm_wday;
}

int sa_tm_yday(){
        long t;
        struct tm *tmbuf;
        t=time(0); tmbuf=localtime(&t); return tmbuf->tm_yday;
}

int sa_tm_isdst(){
        long t;
        struct tm *tmbuf;
        t=time(0); tmbuf=localtime(&t); return tmbuf->tm_isdst;
}

/* end */
