These codes are freely distributed in the sense of
GNU GPL(General Public License).
See COPYING or look for more information at http://www.gnu.org
